package com.example.ivanc.serviciosweb;

/**
 * Created by ivanc on 26/11/2017.
 */

public class Colegio {
    String nombreestablecimiento;
    String calendario;
    String zona;
    String telefono;
    String nombre_Rector;
    String correo_Electronico;
    String direccion;

    public Colegio() {
    }

    public Colegio(String nombreestablecimiento, String calendario, String sector, String telefono, String nombre_Rector, String correo_Electronico, String direccion) {
        this.nombreestablecimiento = nombreestablecimiento;
        this.calendario = calendario;
        this.zona = sector;
        this.telefono = telefono;
        this.nombre_Rector = nombre_Rector;
        this.correo_Electronico = correo_Electronico;
        this.direccion = direccion;
    }

    public String getNombreestablecimiento() {
        return nombreestablecimiento;
    }

    public void setNombreestablecimiento(String nombreestablecimiento) {
        this.nombreestablecimiento = nombreestablecimiento;
    }

    public String getCalendario() {
        return calendario;
    }

    public void setCalendario(String calendario) {
        this.calendario = calendario;
    }

    public String getZona() {
        return zona;
    }

    public void setZona(String sector) {
        this.zona = sector;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getNombre_Rector() {
        return nombre_Rector;
    }

    public void setNombre_Rector(String nombre_Rector) {
        this.nombre_Rector = nombre_Rector;
    }

    public String getCorreo_Electronico() {
        return correo_Electronico;
    }

    public void setCorreo_Electronico(String correo_Electronico) {
        this.correo_Electronico = correo_Electronico;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    @Override
    public String toString() {
        return "Nombre: " + nombreestablecimiento + '\n' +
                "Calendario: " + calendario + '\n' +
                "Zona: " + zona + '\n' +
                "Telefono: " + telefono + '\n' +
                "Rector :" + nombre_Rector + '\n' +
                "E-Mail: " + correo_Electronico + '\n' +
                "Direccion: " + direccion + '\n';
    }
}
