package com.example.ivanc.serviciosweb;

import android.os.AsyncTask;
import android.os.Build;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 * Created by ivanc on 26/11/2017.
 */

public class ViewOperations extends AsyncTask<String, Void, JSONArray> {

    private static final String LOG_TAG = "ViewOperations";
    static int CONNECTION_TIMEOUT = 30000;
    static int DATARETRIEVAL_TIMEOUT = 90000;
    String appurl = "https://www.datos.gov.co/resource/qijw-htwa.json?$$app_token=iSw0A5eP8SOKDny9q61O61Fhs";
    String token = "?$$app_token=iSw0A5eP8SOKDny9q61O61Fhs";
    JSONArray servicio;
    List<Colegio> colegios;

    public ViewOperations() {
    }

    @Override
    protected JSONArray doInBackground(String... urls) {
        return requestWebService(urls[0]);
    }

    protected void onPostExecute(JSONArray items) {
        List<Colegio> colegios = new ArrayList<Colegio>(20);

        try {
            for (int i = 0; i < items.length(); i++) {
                JSONObject obj = items.getJSONObject(i);
                colegios.add(
                        new Colegio(obj.getString("nombreestablecimiento"),
                                obj.getString("calendario"),
                                obj.getString("zona"),
                                obj.getString("telefono"),
                                obj.getString("codigo_etc"),
                                obj.getString("correo_electronico"),
                                obj.getString("direccion")));
            }

        } catch (JSONException e) {
            Log.e(LOG_TAG, "NO es valid JSON string ", e);
            // handle exception
        }
    }

    public List<Colegio> getAllColegios(JSONArray items){
        List<Colegio> colegios = new ArrayList<Colegio>(20);

        try {
            for (int i = 0; i < items.length(); i++) {
                JSONObject obj = items.getJSONObject(i);
                colegios.add(
                        new Colegio(obj.getString("nombreestablecimiento"),
                                obj.getString("calendario"),
                                obj.getString("zona"),
                                obj.getString("telefono"),
                                obj.getString("codigo_etc"),
                                obj.getString("correo_electronico"),
                                obj.getString("direccion")));
            }

        } catch (JSONException e) {
            Log.e(LOG_TAG, "NO es valid JSON string ", e);
            // handle exception
        }
        return colegios;
    }


    public static JSONArray requestWebService(String serviceUrl) {

        JSONArray jarray = null;
        StringBuilder builder = new StringBuilder();

        disableConnectionReuseIfNecessary();

        HttpURLConnection urlConnection = null;
        try {
            // create connection
            URL urlToRequest = new URL(serviceUrl);
            urlConnection = (HttpURLConnection)
                    urlToRequest.openConnection();
            urlConnection.setConnectTimeout(CONNECTION_TIMEOUT);
            urlConnection.setReadTimeout(DATARETRIEVAL_TIMEOUT);

            // handle issues
            int statusCode = urlConnection.getResponseCode();
            if (statusCode == HttpURLConnection.HTTP_UNAUTHORIZED) {
                Log.e("==>", "NO AUTORIZADO");
                // handle unauthorized (if service requires user login)
            } else if (statusCode != HttpURLConnection.HTTP_OK) {
                Log.e("==>", "NO ES OKAY");
                // handle any other errors, like 404, 500,..
            }
            // create JSON object from content
            InputStream in = new BufferedInputStream(urlConnection.getInputStream());
            BufferedReader reader = new BufferedReader(new InputStreamReader(in));
            String line;
            while ((line = reader.readLine()) != null) {
                builder.append(line);
            }
        } catch (MalformedURLException e) {
            Log.e(LOG_TAG, "URL is invalid ");
            // URL is invalid
        } catch (SocketTimeoutException e) {
            // data retrieval or connection timed out
            Log.e(LOG_TAG, "Connection timed out ", e);
        } catch (IOException e) {
            // could not read response body
            // (could not create input stream)
            Log.e(LOG_TAG, "Could not create input stream ", e);
        }

        try {
            jarray = new JSONArray( builder.toString());
            //System.out.println(""+jarray);
        } catch (JSONException e) {
            // response body is no valid JSON string-{
            Log.e(LOG_TAG, "responde is not valid JSON string ", e);
        } finally {
            if (urlConnection != null) {
                urlConnection.disconnect();
            }
        }

        return jarray;
    }

    /**
     * required in order to prevent issues in earlier Android version.
     */
    private static void disableConnectionReuseIfNecessary() {
        // see HttpURLConnection API doc
        if (Integer.parseInt(Build.VERSION.SDK)
                < Build.VERSION_CODES.FROYO) {
            System.setProperty("http.keepAlive", "false");
        }
    }

    private static String getResponseText(InputStream inStream) {
        // very nice trick from
        // http://weblogs.java.net/blog/pat/archive/2004/10/stupid_scanner_1.html
        return new Scanner(inStream).useDelimiter("\\A").next();
    }

}