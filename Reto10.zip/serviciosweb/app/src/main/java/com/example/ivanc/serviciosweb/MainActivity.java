package com.example.ivanc.serviciosweb;

import android.content.Intent;
import android.os.Build;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.util.Scanner;

public class MainActivity extends AppCompatActivity {

    TextView ViewZona;
    TextView ViewCalendario;
    Button ButtonConsultar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ViewZona = (TextView) findViewById(R.id.edit_zona);
        ViewCalendario = (TextView) findViewById(R.id.edit_calendario);
        ButtonConsultar = (Button) findViewById(R.id.button_consultar);

        ButtonConsultar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this, ViewColegios.class);
                i.putExtra("EXTRA_ZONA", ViewZona.getText().toString());
                i.putExtra("EXTRA_CALENDARIO", ViewCalendario.getText().toString());
                startActivity(i);
            }
        });
    }

}
