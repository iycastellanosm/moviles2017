package com.example.ivanc.serviciosweb;

import android.app.ListActivity;
import android.os.Build;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ArrayAdapter;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.concurrent.ExecutionException;

/**
 * Created by ivanc on 25/11/2017.
 */

public class ViewColegios  extends ListActivity {
    List<Colegio> colegios;
    ViewOperations operations;
    String calendario;
    String zona;
    String url = "https://www.datos.gov.co/resource/qijw-htwa.json?$$app_token=iSw0A5eP8SOKDny9q61O61Fhs";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.view_activity);

        String nuevourl = url;

        calendario = getIntent().getStringExtra("EXTRA_CALENDARIO");
        zona = getIntent().getStringExtra("EXTRA_ZONA");

        operations = new ViewOperations();
        if(calendario!=null && calendario.length()>0){
            nuevourl += "&calendario=";
            nuevourl += calendario;
        }
        if(zona!=null && zona.length()>0){
            nuevourl += "&zona=";
            nuevourl += zona;
        }
        try {
            colegios = operations.getAllColegios(operations.execute(nuevourl).get());
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (ExecutionException e) {
            e.printStackTrace();
        }
        ArrayAdapter<Colegio> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1, colegios);
        setListAdapter(adapter);
    }

}
