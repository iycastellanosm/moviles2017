package com.example.ivanc.sqliteapp.DB;

/**
 * Created by ivanc on 20/11/2017.
 */


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import com.example.ivanc.sqliteapp.Model.Empresa;

import java.util.ArrayList;
import java.util.List;


public class EmpresaOperations {
    public static final String LOGTAG = "EMP_MNGMNT_SYS";

    SQLiteOpenHelper dbhandler;
    SQLiteDatabase database;

    private static final String[] allColumns = {
            EmpresaDBHandler.COLUMN_ID,
            EmpresaDBHandler.COLUMN_NAME,
            EmpresaDBHandler.COLUMN_URL,
            EmpresaDBHandler.COLUMN_EMAIL,
            EmpresaDBHandler.COLUMN_PHONE,
            EmpresaDBHandler.COLUMN_PRODUCTS,
            EmpresaDBHandler.COLUMN_CLASS
    };

    public EmpresaOperations(Context context){
        dbhandler = new EmpresaDBHandler(context);
    }

    public void open(){
        Log.i(LOGTAG,"Database Opened");
        database = dbhandler.getWritableDatabase();
    }

    public void close(){
        Log.i(LOGTAG, "Database Closed");
        dbhandler.close();

    }
    public Empresa addEmpresa(Empresa Emp){
        ContentValues values  = new ContentValues();
        values.put(EmpresaDBHandler.COLUMN_NAME, Emp.getName());
        values.put(EmpresaDBHandler.COLUMN_URL, Emp.getUrl());
        values.put(EmpresaDBHandler.COLUMN_EMAIL, Emp.getEmail());
        values.put(EmpresaDBHandler.COLUMN_PHONE, Emp.getPhone());
        values.put(EmpresaDBHandler.COLUMN_PRODUCTS, Emp.getProds());
        values.put(EmpresaDBHandler.COLUMN_CLASS, Emp.getClassif());
        long insertid = database.insert(EmpresaDBHandler.TABLE_EMPRESAS,null,values);
        Emp.setEmpId(insertid);
        return Emp;

    }

    // Getting single Employee
    public Empresa getEmpresa(long id) {

        Cursor cursor = database.query(EmpresaDBHandler.TABLE_EMPRESAS,allColumns,EmpresaDBHandler.COLUMN_ID + "=?",new String[]{String.valueOf(id)},null,null, null, null);
        if (cursor != null)
            cursor.moveToFirst();

        Empresa e = new Empresa(Long.parseLong(cursor.getString(0)),cursor.getString(1),cursor.getString(2),cursor.getString(3),cursor.getString(4),cursor.getString(5),cursor.getString(6));
        // return Employee
        return e;
    }

    public List<Empresa> getAllEmpresas() {

        Cursor cursor = database.query(EmpresaDBHandler.TABLE_EMPRESAS,allColumns,null,null,null,null,null);

        List<Empresa> empresas = new ArrayList<>();
        if(cursor.getCount() > 0){
            while(cursor.moveToNext()){
                Empresa emp = new Empresa();
                emp.setEmpId(cursor.getLong(cursor.getColumnIndex(EmpresaDBHandler.COLUMN_ID)));
                emp.setName(cursor.getString(cursor.getColumnIndex(EmpresaDBHandler.COLUMN_NAME)));
                emp.setUrl(cursor.getString(cursor.getColumnIndex(EmpresaDBHandler.COLUMN_URL)));
                emp.setEmail(cursor.getString(cursor.getColumnIndex(EmpresaDBHandler.COLUMN_EMAIL)));
                emp.setPhone(cursor.getString(cursor.getColumnIndex(EmpresaDBHandler.COLUMN_PHONE)));
                emp.setProds(cursor.getString(cursor.getColumnIndex(EmpresaDBHandler.COLUMN_PRODUCTS)));
                emp.setClassif(cursor.getString(cursor.getColumnIndex(EmpresaDBHandler.COLUMN_CLASS)));
                empresas.add(emp);
            }
        }
        // return All Empresas
        return empresas;
    }


    // Updating Empresa
    public int updateEmpresa(Empresa emp) {

        ContentValues values = new ContentValues();
        values.put(EmpresaDBHandler.COLUMN_NAME, emp.getName());
        values.put(EmpresaDBHandler.COLUMN_URL, emp.getUrl());
        values.put(EmpresaDBHandler.COLUMN_EMAIL, emp.getEmail());
        values.put(EmpresaDBHandler.COLUMN_PHONE, emp.getPhone());
        values.put(EmpresaDBHandler.COLUMN_PRODUCTS, emp.getProds());
        values.put(EmpresaDBHandler.COLUMN_CLASS, emp.getClassif());

        // updating row
        return database.update(EmpresaDBHandler.TABLE_EMPRESAS, values,
                EmpresaDBHandler.COLUMN_ID + "=?",new String[] { String.valueOf(emp.getEmpId())});
    }

    // Deleting Empresa
    public void removeEmpresa(Empresa emp) {
        database.delete(EmpresaDBHandler.TABLE_EMPRESAS, EmpresaDBHandler.COLUMN_ID + "=" + emp.getEmpId(), null);
    }



}