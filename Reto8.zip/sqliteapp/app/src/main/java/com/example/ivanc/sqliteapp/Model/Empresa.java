package com.example.ivanc.sqliteapp.Model;

/**
 * Created by ivanc on 14/11/2017.
 */

public class Empresa {
    private long empId;
    private String name;
    private String url;
    private String phone;
    private String email;
    private String prods;
    private String classif;

    public Empresa(long empId, String name, String url, String email, String phone, String prods, String classif) {
        this.empId = empId;
        this.name = name;
        this.url = url;
        this.email = email;
        this.phone = phone;
        this.prods = prods;
        this.classif = classif;
    }

    public Empresa() {

    }

    public long getEmpId() {
        return empId;
    }

    public void setEmpId(long empId) {
        this.empId = empId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getProds() {
        return prods;
    }

    public void setProds(String prods) {
        this.prods = prods;
    }

    public String getClassif() {
        return classif;
    }

    public void setClassif(String classif) {
        this.classif = classif;
    }

    public String toString() {
        return "Id: " + getEmpId() + "\n" +
                "Name: " + getName() + "\n" +
                "URL: " + getUrl() + "\n" +
                "E-Mail: " + getEmail() + "\n" +
                "Phone: " + getPhone() + "\n" +
                "Products and Services: " + getProds() + "\n" +
                "Classification : " + getClassif();
    }

}
