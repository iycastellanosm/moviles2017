package com.example.ivanc.sqliteapp;

/**
 * Created by ivanc on 20/11/2017.
 */

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.example.ivanc.sqliteapp.DB.EmpresaOperations;
import com.example.ivanc.sqliteapp.Model.Empresa;

public class AddUpdateEmpresa extends AppCompatActivity{

    private static final String EXTRA_EMP_ID = "com.example.ivanc.empId";
    private static final String EXTRA_ADD_UPDATE = "com.example.ivanc.add_update";
    private static final String DIALOG_DATE = "DialogDate";
    private RadioGroup radioGroup;
    private RadioButton publicRadioButton,privateRadioButton, mixtoRadioButton;
    private EditText NameEditText;
    private EditText UrlEditText;
    private EditText EmailEditText;
    private EditText PhoneEditText;
    private EditText ProductsEditText;
    private Button addUpdateButton;
    private Empresa newEmpresa;
    private Empresa oldEmpresa;
    private String mode;
    private long empId;
    private EmpresaOperations empresaData;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_update_empresa);
        newEmpresa = new Empresa();
        oldEmpresa = new Empresa();
        NameEditText = (EditText)findViewById(R.id.edit_text_name);
        UrlEditText = (EditText)findViewById(R.id.edit_text_url);
        EmailEditText = (EditText)findViewById(R.id.edit_text_email);
        PhoneEditText = (EditText) findViewById(R.id.edit_text_phone);
        ProductsEditText = (EditText)findViewById(R.id.edit_text_products);
        radioGroup = (RadioGroup) findViewById(R.id.radio_class);
        publicRadioButton = (RadioButton) findViewById(R.id.radio_publico);
        privateRadioButton = (RadioButton) findViewById(R.id.radio_privado);
        mixtoRadioButton = (RadioButton) findViewById(R.id.radio_mixto);
        addUpdateButton = (Button)findViewById(R.id.button_add_update_empresa);
        empresaData = new EmpresaOperations(this);
        empresaData.open();


        mode = getIntent().getStringExtra(EXTRA_ADD_UPDATE);
        if(mode.equals("Update")){

            addUpdateButton.setText(R.string.update);
            empId = getIntent().getLongExtra(EXTRA_EMP_ID,0);

            initializeEmployee(empId);

        }

        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {

            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                // find which radio button is selected
                if (checkedId == R.id.radio_publico) {
                    newEmpresa.setClassif("Publico");
                    if(mode.equals("Update")){
                        oldEmpresa.setClassif("Publico");
                    }
                } else if (checkedId == R.id.radio_privado) {
                    newEmpresa.setClassif("Privado");
                    if(mode.equals("Update")){
                        oldEmpresa.setClassif("Privado");
                    }
                }else if (checkedId == R.id.radio_mixto) {
                    newEmpresa.setClassif("Mixto");
                    if(mode.equals("Update")){
                        oldEmpresa.setClassif("Mixto");
                    }
                }
            }

        });

        addUpdateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(mode.equals("Add")) {
                    newEmpresa.setName(NameEditText.getText().toString());
                    newEmpresa.setUrl(UrlEditText.getText().toString());
                    newEmpresa.setPhone(PhoneEditText.getText().toString());
                    newEmpresa.setEmail(EmailEditText.getText().toString());
                    newEmpresa.setProds(ProductsEditText.getText().toString());
                    empresaData.addEmpresa(newEmpresa);
                    Toast t = Toast.makeText(AddUpdateEmpresa.this, "La empresa "+ newEmpresa.getName() + " se ha agregado exitosamente !", Toast.LENGTH_SHORT);
                    t.show();
                    Intent i = new Intent(AddUpdateEmpresa.this,MainActivity.class);
                    startActivity(i);
                }else {
                    oldEmpresa.setName(NameEditText.getText().toString());
                    oldEmpresa.setUrl(UrlEditText.getText().toString());
                    oldEmpresa.setPhone(PhoneEditText.getText().toString());
                    oldEmpresa.setEmail(EmailEditText.getText().toString());
                    oldEmpresa.setProds(ProductsEditText.getText().toString());
                    empresaData.updateEmpresa(oldEmpresa);
                    Toast t = Toast.makeText(AddUpdateEmpresa.this, "La empresa "+ oldEmpresa.getName() + " se ha actualizado exitosamente !", Toast.LENGTH_SHORT);
                    t.show();
                    Intent i = new Intent(AddUpdateEmpresa.this,MainActivity.class);
                    startActivity(i);
                }
            }
        });


    }

    private void initializeEmployee(long empId) {
        oldEmpresa = empresaData.getEmpresa(empId);
        NameEditText.setText(oldEmpresa.getName());
        UrlEditText.setText(oldEmpresa.getUrl());
        EmailEditText.setText(oldEmpresa.getEmail());
        PhoneEditText.setText(oldEmpresa.getPhone());
        ProductsEditText.setText(oldEmpresa.getProds());
        if(oldEmpresa.getClassif().equals("Publico")){
            radioGroup.check(R.id.radio_publico);
        } else if(oldEmpresa.getClassif().equals("Privado")){
            radioGroup.check(R.id.radio_privado);
        } else {
            radioGroup.check(R.id.radio_mixto);
        }
    }

}
