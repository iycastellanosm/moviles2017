package com.example.ivanc.sqliteapp.DB;

/**
 * Created by ivanc on 20/11/2017.
 */

import android.database.sqlite.SQLiteOpenHelper;

        import android.content.Context;
        import android.database.sqlite.SQLiteDatabase;
        import android.database.sqlite.SQLiteOpenHelper;
        import android.util.Log;


public class EmpresaDBHandler extends SQLiteOpenHelper {


    private static final String DATABASE_NAME = "empresas.db";
    private static final int DATABASE_VERSION = 1;

    public static final String TABLE_EMPRESAS = "empresas";
    public static final String COLUMN_ID = "empId";
    public static final String COLUMN_NAME = "name";
    public static final String COLUMN_URL = "url";
    public static final String COLUMN_EMAIL = "email";
    public static final String COLUMN_PHONE = "phone";
    public static final String COLUMN_PRODUCTS = "products";
    public static final String COLUMN_CLASS = "class";

    private static final String TABLE_CREATE =
            "CREATE TABLE " + TABLE_EMPRESAS + " (" +
                    COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COLUMN_NAME + " TEXT, " +
                    COLUMN_URL + " TEXT, " +
                    COLUMN_EMAIL + " TEXT, " +
                    COLUMN_PHONE + " NUMERIC, " +
                    COLUMN_PRODUCTS + " TEXT, " +
                    COLUMN_CLASS + " TEXT " +
                    ")";

    public EmpresaDBHandler(Context context){
        super(context,DATABASE_NAME,null,DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(TABLE_CREATE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_EMPRESAS);
        db.execSQL(TABLE_CREATE);
    }
}