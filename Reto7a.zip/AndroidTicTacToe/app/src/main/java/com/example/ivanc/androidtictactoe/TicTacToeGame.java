package com.example.ivanc.androidtictactoe;

/**
 * Created by ivanc on 28/08/2017.
 */

import java.util.Random;
import java.util.*;

public class TicTacToeGame {

    // The computer's difficulty levels
    public enum DifficultyLevel {Easy, Harder, Expert};

    // Current difficulty level
    private DifficultyLevel mDifficultyLevel = DifficultyLevel.Expert;

    // Characters used to represent the human, computer, and open spots

    public ArrayList<String> mBoard;
    public boolean finished = false;

    public static final int BOARD_SIZE = 9;
    public static final String HUMAN_PLAYER = "O";
    public static final String COMPUTER_PLAYER = "X";
    public static final String OPEN_SPOT = " ";

    public String turn = HUMAN_PLAYER;

    private Random mRand;

    public TicTacToeGame() {

        // Seed the random number generator
        mRand = new Random();
        mBoard = new ArrayList<>();

            // Human starts first
        int  win = 0;                // Set to 1, 2, or 3 when game is over

        for(char i = '1'; i<='9'; i++){
            mBoard.add(Integer.toString(i));
        }
    }



    /** Clear the board of all X's and O's by setting all spots to OPEN_SPOT. */
    public void clearBoard(){
        for (int i = 0; i < BOARD_SIZE; i++){
            mBoard.set(i, OPEN_SPOT);
        }
    }

    public String getBoardOccupant(int i) {
        return mBoard.get(i);
    }

    /** Set the given player at the given location on the game board.
     * The location must be available, or the board will not be changed.
     *
     * @param player - The HUMAN_PLAYER or COMPUTER_PLAYER
     * @param location - The location (0-8) to place the move
     */
    public boolean setMove(String player, int location){
        if(!mBoard.get(location).equals(OPEN_SPOT)) {
            return false;
        }
        //    return false;
        mBoard.set(location, player);
        return true;
    }

    public ArrayList<String> getBoardState(){
        return mBoard;
    }

    public void setBoardState(ArrayList<String> tablero){
        mBoard = (ArrayList<String>) tablero.clone();
    }

    /** Return the best move for the computer to make. You must call setMove()
     * to actually make the computer move to that location.
     * @return The best move for the computer to make (0-8).
     */
    public int getComputerMove()
    {
        int move = -1;
        //System.out.println("Computer is moving to " + (move + 1))

        if (mDifficultyLevel == DifficultyLevel.Easy)
            move = getRandomMove();
        else if (mDifficultyLevel == DifficultyLevel.Harder) {
            move = getWinningMove();
            if (move == -1)
                move = getRandomMove();
        }
        else if (mDifficultyLevel == DifficultyLevel.Expert) {

            // Try to win, but if that's not possible, block.
            // If that's not possible, move anywhere.
            move = getWinningMove();
            if (move == -1)
                move = getBlockingMove();
            if (move == -1)
                move = getRandomMove();
        }

        //setMove(COMPUTER_PLAYER, move);
        return move;

    }


    // Generate random move
    public int getRandomMove(){
        int move = -1;
        int cnt = 0;
        do
        {
            move = mRand.nextInt(BOARD_SIZE);
            cnt = cnt | (1<<(move));
        } while ((mBoard.get(move).equals(HUMAN_PLAYER) || mBoard.get(move).equals(COMPUTER_PLAYER)) && cnt != 511);
        //mBoard.set(move, COMPUTER_PLAYER);
        return move;
    }

    // See if there's a move O can make to block X from winning
    public int getBlockingMove(){
        int move = -1;
        for (int i = 0; i < BOARD_SIZE; i++) {
            if (!mBoard.get(i).equals(HUMAN_PLAYER) && !mBoard.get(i).equals(COMPUTER_PLAYER)) {
                String curr = mBoard.get(i);   // Save the current number
                mBoard.set(i, HUMAN_PLAYER);
                if (checkForWinner() == 2) {
                    //System.out.println("Computer is moving to " + (i + 1));
                    mBoard.set(i, curr);
                    return i;
                } else
                    mBoard.set(i, curr);
            }
        }
        return move;
    }

    public int getWinningMove(){
        // First see if there's a move O can make to win
        int move = -1;
        for (int i = 0; i < BOARD_SIZE; i++) {
            if (!mBoard.get(i).equals(HUMAN_PLAYER) && !mBoard.get(i).equals(COMPUTER_PLAYER)) {
                String curr = mBoard.get(i);
                mBoard.set(i, COMPUTER_PLAYER);
                if (checkForWinner() == 3) {
                    //System.out.println("Computer is moving to " + (i + 1));
                    mBoard.set(i, curr);
                    return i;
                } else
                    mBoard.set(i, curr);
            }
        }
        return move;
    }

    /**
     * Check for a winner and return a status value indicating who has won.
     * @return Return 0 if no winner or tie yet, 1 if it's a tie, 2 if X won,
     * or 3 if O won.
     */
    public int checkForWinner() {

        // Check horizontal wins
        for (int i = 0; i <= 6; i += 3)	{
            if (mBoard.get(i).equals(HUMAN_PLAYER) &&
                    mBoard.get(i+1).equals(HUMAN_PLAYER) &&
                    mBoard.get(i+2).equals(HUMAN_PLAYER))
                return 2;
            if (mBoard.get(i).equals(COMPUTER_PLAYER) &&
                    mBoard.get(i+1).equals(COMPUTER_PLAYER) &&
                    mBoard.get(i+2).equals(COMPUTER_PLAYER))
                return 3;
        }

        // Check vertical wins
        for (int i = 0; i <= 2; i++) {
            if (mBoard.get(i).equals(HUMAN_PLAYER) &&
                    mBoard.get(i+3).equals(HUMAN_PLAYER) &&
                    mBoard.get(i+6).equals(HUMAN_PLAYER))
                return 2;
            if (mBoard.get(i).equals(COMPUTER_PLAYER) &&
                    mBoard.get(i+3).equals(COMPUTER_PLAYER) &&
                    mBoard.get(i+6).equals(COMPUTER_PLAYER))
                return 3;
        }

        // Check for diagonal wins
        if ((mBoard.get(0).equals(HUMAN_PLAYER) &&
                mBoard.get(4).equals(HUMAN_PLAYER) &&
                mBoard.get(8).equals(HUMAN_PLAYER)) ||
                (mBoard.get(2).equals(HUMAN_PLAYER) &&
                        mBoard.get(4).equals(HUMAN_PLAYER) &&
                        mBoard.get(6).equals(HUMAN_PLAYER)))
            return 2;
        if ((mBoard.get(0).equals(COMPUTER_PLAYER) &&
                mBoard.get(4).equals(COMPUTER_PLAYER) &&
                mBoard.get(8).equals(COMPUTER_PLAYER)) ||
                (mBoard.get(2).equals(COMPUTER_PLAYER) &&
                        mBoard.get(4).equals(COMPUTER_PLAYER) &&
                        mBoard.get(6).equals(COMPUTER_PLAYER)))
            return 3;

        // Check for tie
        for (int i = 0; i < BOARD_SIZE; i++) {
            // If we find a number, then no one has won yet
            if (!mBoard.get(i).equals(HUMAN_PLAYER) && !mBoard.get(i).equals(COMPUTER_PLAYER))
                return 0;
        }

        // If we make it through the previous loop, all places are taken, so it's a tie
        return 1;
    }

    public DifficultyLevel getDifficultyLevel() {
        return mDifficultyLevel;
    }

    public void setDifficultyLevel(DifficultyLevel difficultyLevel) {
        mDifficultyLevel = difficultyLevel;
    }

}