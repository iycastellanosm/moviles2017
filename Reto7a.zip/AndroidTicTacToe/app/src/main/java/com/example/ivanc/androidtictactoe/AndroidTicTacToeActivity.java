package com.example.ivanc.androidtictactoe;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.media.MediaPlayer;
import android.preference.PreferenceManager;
import android.support.annotation.NonNull;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Random;

public class AndroidTicTacToeActivity extends AppCompatActivity {

    //static final int DIALOG_DIFFICULTY_ID = 0;
    static final int DIALOG_QUIT_ID = 1;
    private String PLAYER;
    private int IDGAME;
    private DatabaseReference mDatabase;

    private TicTacToeGame mGame;
    // Various text displayed
    private TextView mGameTextView;
    private TextView mInfoTextView;
    private TextView mTieScoreTextView;
    private TextView mComputerScoreTextView;
    private TextView mHumanScoreTextView;
    private boolean mGameOver;
    private boolean mSoundOn;
    private SharedPreferences mPrefs;
    private int mComputerWins;
    private int mHumanWins;
    private int mTies;
    private char mGoFirst;

    private BoardView mBoardView;

    MediaPlayer mHumanMediaPlayer;
    MediaPlayer mComputerMediaPlayer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_android_tic_tac_toe);

        PLAYER = getIntent().getStringExtra("EXTRA_PLAYER");
        mDatabase = FirebaseDatabase.getInstance().getReference();
        mGameTextView = (TextView) findViewById(R.id.numbergame);
        mInfoTextView = (TextView) findViewById(R.id.information);
        mHumanScoreTextView  = (TextView) findViewById(R.id.humanscore);
        mComputerScoreTextView = (TextView) findViewById(R.id.computerscore);
        mTieScoreTextView = (TextView) findViewById(R.id.tiescore);
        mGame = new TicTacToeGame();
        mBoardView = (BoardView) findViewById(R.id.board);

        if(PLAYER.equals("H1")){
            Random r = new Random();
            IDGAME = r.nextInt(10000);
            mGameTextView.setText(Integer.toString(IDGAME));
            mBoardView.setGame(mGame);
            startNewGame();
            mDatabase.child(Integer.toString(IDGAME)).setValue(mGame).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {
                    Log.d(null, e.getLocalizedMessage());
                }
            });
            mDatabase.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {
                    mGame = dataSnapshot.child(Integer.toString(IDGAME)).getValue(TicTacToeGame.class);
                    mBoardView.setGame(mGame);
                    mBoardView.invalidate();
                    update();
                }

                @Override
                public void onCancelled(DatabaseError databaseError) {

                }
            });
        }
        else if(PLAYER.equals("H2")){
            IDGAME = Integer.valueOf(getIntent().getStringExtra("EXTRA_GAME"));
            mGameTextView.setText(Integer.toString(IDGAME));
            mDatabase.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {
                    mGame = dataSnapshot.child(Integer.toString(IDGAME)).getValue(TicTacToeGame.class);
                    mBoardView.setGame(mGame);
                    mBoardView.invalidate();
                    update();
                }

                @Override
                public void onCancelled(DatabaseError databaseError) {

                }
            });
            mGameOver = false;
        }
        else{
            mBoardView.setGame(mGame);
            startNewGame();
        }


        // Restore the scores from the persistent preference data source
        mPrefs = PreferenceManager.getDefaultSharedPreferences(this);
        mSoundOn = mPrefs.getBoolean("sound", true);
        String difficultyLevel = mPrefs.getString("difficulty_level", getResources().getString(R.string.difficulty_harder));
        if (difficultyLevel.equals(getResources().getString(R.string.difficulty_easy)))
            mGame.setDifficultyLevel(TicTacToeGame.DifficultyLevel.Easy);
        else if (difficultyLevel.equals(getResources().getString(R.string.difficulty_harder)))
            mGame.setDifficultyLevel(TicTacToeGame.DifficultyLevel.Harder);
        else
            mGame.setDifficultyLevel(TicTacToeGame.DifficultyLevel.Expert);


        mPrefs = getSharedPreferences("ttt_prefs", MODE_PRIVATE);

        // Restore the scores
        mHumanWins = mPrefs.getInt("mHumanWins", 0);
        mComputerWins = mPrefs.getInt("mComputerWins", 0);
        mTies = mPrefs.getInt("mTies", 0);

        // Listen for touches on the board
        mBoardView.setOnTouchListener(mTouchListener);

        if (savedInstanceState == null) {
            startNewGame();
        }
        else {
            // Restore the game's state
            mGame.setBoardState(savedInstanceState.getStringArrayList("board"));
            mGameOver = savedInstanceState.getBoolean("mGameOver");
            mGameTextView.setText(savedInstanceState.getCharSequence("numbergame"));
            mInfoTextView.setText(savedInstanceState.getCharSequence("info"));
            mHumanWins = savedInstanceState.getInt("mHumanWins");
            mComputerWins = savedInstanceState.getInt("mComputerWins");
            mTies = savedInstanceState.getInt("mTies");
            mGoFirst = savedInstanceState.getChar("mGoFirst");
        }
        displayScores();

    }

    private void displayScores() {
        mHumanScoreTextView.setText(Integer.toString(mHumanWins));
        mComputerScoreTextView.setText(Integer.toString(mComputerWins));
        mTieScoreTextView.setText(Integer.toString(mTies));
    }

    private void startNewGame(){
        mGame.clearBoard();
        mBoardView.invalidate();
        mGameOver = false;
        if(PLAYER.equals("H2")){
            mInfoTextView.setText(R.string.first_pc);
        }
        else {
            mInfoTextView.setText(R.string.first_human);
        }
    }

    // Listen for touches on the board
    private View.OnTouchListener mTouchListener = new View.OnTouchListener() {
        public boolean onTouch(View v, MotionEvent event) {

            // Determine which cell was touched
            int col = (int) event.getX() / mBoardView.getBoardCellWidth();
            int row = (int) event.getY() / mBoardView.getBoardCellHeight();
            int pos = row * 3 + col;

            if (!mGameOver)	{
                if(PLAYER.equals("PC")) {
                    if (setMove(TicTacToeGame.HUMAN_PLAYER, pos)) {
                        mGame.turn = TicTacToeGame.COMPUTER_PLAYER;
                        // If no winner yet, let the computer make a move
                        int winner = mGame.checkForWinner();
                        if (winner == 0) {
                            mInfoTextView.setText(R.string.turn_computer);
                            int move;
                            move = mGame.getComputerMove();
                            setMove(TicTacToeGame.COMPUTER_PLAYER, move);
                            winner = mGame.checkForWinner();
                        }
                        if (winner == 0)
                            mInfoTextView.setText(R.string.turn_human);
                        else {
                            mGameOver = true;
                            if (winner == 1) {
                                mInfoTextView.setText(R.string.result_tie);
                                mTies++;
                            } else if (winner == 2) {
                                mHumanWins++;
                                mHumanScoreTextView.setText(Integer.toString(mHumanWins));
                                String defaultMessage = getResources().getString(R.string.result_human_wins);
                                mInfoTextView.setText(mPrefs.getString("victory_message", defaultMessage));
                            } else {
                                mInfoTextView.setText(R.string.result_computer_wins);
                                mComputerWins++;
                            }
                            displayScores();
                        }
                    }
                }
                else if(PLAYER.equals("H1")) {
                    if (mGame.turn.equals(TicTacToeGame.HUMAN_PLAYER)){
                        if(setMove(TicTacToeGame.HUMAN_PLAYER, pos)) {
                            // If no winner yet, let the computer make a move
                            int winner = mGame.checkForWinner();
                            if (winner == 0) {
                                mInfoTextView.setText(R.string.turn_computer);
                                mGame.turn = TicTacToeGame.COMPUTER_PLAYER;
                            } else {
                                mGameOver = true;
                                if (winner == 1) {
                                    mInfoTextView.setText(R.string.result_tie);
                                    mTies++;
                                } else if (winner == 2) {
                                    mHumanWins++;
                                    mHumanScoreTextView.setText(Integer.toString(mHumanWins));
                                    String defaultMessage = getResources().getString(R.string.result_human_wins);
                                    mInfoTextView.setText(mPrefs.getString("victory_message", defaultMessage));
                                } else {
                                    mInfoTextView.setText(R.string.result_computer_wins);
                                    mComputerWins++;
                                }
                                displayScores();
                            }
                            mDatabase.child(Integer.toString(IDGAME)).setValue(mGame).addOnFailureListener(new OnFailureListener() {
                                @Override
                                public void onFailure(@NonNull Exception e) {
                                    Log.d(null, e.getLocalizedMessage());
                                }
                            });
                        }
                    }
                }
                else{
                    if (mGame.turn.equals(TicTacToeGame.COMPUTER_PLAYER)){
                        if(setMove(TicTacToeGame.COMPUTER_PLAYER, pos)) {
                            mGame.turn = TicTacToeGame.HUMAN_PLAYER;
                            // If no winner yet, let the computer make a move
                            int winner = mGame.checkForWinner();
                            if (winner == 0) {
                                mInfoTextView.setText(R.string.turn_computer);
                            } else {
                                mGameOver = true;
                                if (winner == 1) {
                                    mInfoTextView.setText(R.string.result_tie);
                                    mTies++;
                                } else if (winner == 3) {
                                    mHumanWins++;
                                    mHumanScoreTextView.setText(Integer.toString(mHumanWins));
                                    String defaultMessage = getResources().getString(R.string.result_human_wins);
                                    mInfoTextView.setText(mPrefs.getString("victory_message", defaultMessage));
                                } else {
                                    mInfoTextView.setText(R.string.result_computer_wins);
                                    mComputerWins++;
                                }
                                displayScores();
                            }
                            mDatabase.child(Integer.toString(IDGAME)).setValue(mGame).addOnFailureListener(new OnFailureListener() {
                                @Override
                                public void onFailure(@NonNull Exception e) {
                                    Log.d(null, e.getLocalizedMessage());
                                }
                            });
                        }
                    }
                }
            }

        // So we aren't notified of continued events when finger is moved
            return false;
        }
    };

    private void update(){
        int winner = mGame.checkForWinner();
        if (winner == 0) {
            if((mGame.turn.equals(TicTacToeGame.HUMAN_PLAYER) && PLAYER.equals("H1")) || (mGame.turn.equals(TicTacToeGame.COMPUTER_PLAYER) && PLAYER.equals("H2")))
                mInfoTextView.setText(R.string.turn_human);
            else
                mInfoTextView.setText(R.string.turn_computer);
        } else {
            mGameOver = true;
            if (winner == 1) {
                mInfoTextView.setText(R.string.result_tie);
                mTies++;
            } else if ((winner == 2 && PLAYER.equals("H1")) || (winner == 3 && PLAYER.equals("H2"))) {
                mHumanWins++;
                mHumanScoreTextView.setText(Integer.toString(mHumanWins));
                String defaultMessage = getResources().getString(R.string.result_human_wins);
                mInfoTextView.setText(mPrefs.getString("victory_message", defaultMessage));
            } else {
                mInfoTextView.setText(R.string.result_computer_wins);
                mComputerWins++;
            }
            displayScores();
        }
    }

    private boolean setMove(String player, int location) {
        if (mGame.setMove(player, location)) {
            mBoardView.invalidate();   // Redraw the board
            if(player.equals(TicTacToeGame.HUMAN_PLAYER)){
                if(mSoundOn) mHumanMediaPlayer.start();
                //else mHumanMediaPlayer.stop();
            }
            else{
                if(mSoundOn) mComputerMediaPlayer.start();
                //else mComputerMediaPlayer.stop();
            }
            return true;
        }
        return false;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);

        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.options_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.new_game:
                startNewGame();
                return true;
            case R.id.settings:
                startActivityForResult(new Intent(this, Settings.class), 0);
                return true;
            case R.id.quit:
                showDialog(DIALOG_QUIT_ID);
                return true;
        }
        return false;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        if (requestCode == RESULT_CANCELED) {
            // Apply potentially new settings
            mSoundOn = mPrefs.getBoolean("sound", true);

            String difficultyLevel = mPrefs.getString("difficulty_level",
                    getResources().getString(R.string.difficulty_harder));

            if (difficultyLevel.equals(getResources().getString(R.string.difficulty_easy)))
                mGame.setDifficultyLevel(TicTacToeGame.DifficultyLevel.Easy);
            else if (difficultyLevel.equals(getResources().getString(R.string.difficulty_harder)))
                mGame.setDifficultyLevel(TicTacToeGame.DifficultyLevel.Harder);
            else
                mGame.setDifficultyLevel(TicTacToeGame.DifficultyLevel.Expert);
        }
    }

    @Override
    protected Dialog onCreateDialog(int id) {
        Dialog dialog = null;
        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        switch(id) {
            case DIALOG_QUIT_ID:
                // Create the quit confirmation dialog

                builder.setMessage(R.string.quit_question)
                        .setCancelable(false)
                        .setPositiveButton(R.string.yes, new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                AndroidTicTacToeActivity.this.finish();
                            }
                        })
                        .setNegativeButton(R.string.no, null);
                dialog = builder.create();

                break;
        }

        return dialog;
    }

    @Override
    protected void onResume() {
        super.onResume();

        mHumanMediaPlayer = MediaPlayer.create(getApplicationContext(), R.raw.sonido_equis);
        mComputerMediaPlayer = MediaPlayer.create(getApplicationContext(), R.raw.sonido_circulo);
    }

    @Override
    protected void onPause() {
        super.onPause();

        mHumanMediaPlayer.release();
        mComputerMediaPlayer.release();
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);

        outState.putStringArrayList("board", mGame.getBoardState());
        outState.putBoolean("mGameOver", mGameOver);
        outState.putInt("mHumanWins", Integer.valueOf(mHumanWins));
        outState.putInt("mComputerWins", Integer.valueOf(mComputerWins));
        outState.putInt("mTies", Integer.valueOf(mTies));
        outState.putCharSequence("numbergame", mGameTextView.getText());
        outState.putCharSequence("info", mInfoTextView.getText());
        outState.putChar("mGoFirst", mGoFirst);
    }

    @Override
    protected void onStop() {
        super.onStop();

        // Save the current scores
        SharedPreferences.Editor ed = mPrefs.edit();
        ed.putInt("mHumanWins", mHumanWins);
        ed.putInt("mComputerWins", mComputerWins);
        ed.putInt("mTies", mTies);
        ed.commit();
    }

}
