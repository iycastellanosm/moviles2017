package com.example.ivanc.androidtictactoe;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

/**
 * Created by ivanc on 27/10/2017.
 */

public class Main extends AppCompatActivity {

    private EditText mLogin;
    private DatabaseReference mDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        mDatabase = FirebaseDatabase.getInstance().getReference();
        mLogin = (EditText)findViewById(R.id.gamenumber);
    }

    public void nuevaactividadpc(View View){
        Context context = getApplicationContext();
        CharSequence text = "Iniciando Juego";
        int duration = Toast.LENGTH_SHORT;
        Toast toast = Toast.makeText(context, text, duration);
        toast.show();
        Intent intent = new Intent(this,AndroidTicTacToeActivity.class);
        intent.putExtra("EXTRA_PLAYER", "PC");
        startActivity(intent);
    }

    public void nuevaactividadhumano(View View){
        Context context = getApplicationContext();
        CharSequence text = "Iniciando Juego";
        int duration = Toast.LENGTH_SHORT;
        Toast toast = Toast.makeText(context, text, duration);
        toast.show();
        Intent intent = new Intent(this,AndroidTicTacToeActivity.class);
        intent.putExtra("EXTRA_PLAYER", "H1");
        startActivity(intent);
    }

    public void usadaactividad(View View){
        final String ngame = mLogin.getText().toString();

        final Intent intent = new Intent(this,AndroidTicTacToeActivity.class);
        intent.putExtra("EXTRA_PLAYER", "H2");
        intent.putExtra("EXTRA_GAME", ngame);
        //if (mDatabase.child(ngame).)
        mDatabase.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if(ngame.equals("") || !dataSnapshot.hasChild(ngame)){
                    Context context = getApplicationContext();
                    CharSequence text = "Juego No Existente !!!";
                    int duration = Toast.LENGTH_SHORT;
                    Toast toast = Toast.makeText(context, text, duration);
                    toast.show();
                }
                else{
                    Context context = getApplicationContext();
                    CharSequence text = "Entrando a Juego";
                    int duration = Toast.LENGTH_SHORT;
                    Toast toast = Toast.makeText(context, text, duration);
                    toast.show();
                    startActivity(intent);
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

    }
}
